import axios from 'axios';

// API Configuration
const baseURL = 'http://localhost:8000/api';

// Create axios instance with base configuration
const api = axios.create({
  baseURL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000, // 10 seconds timeout
});

// Response interceptor for handling errors
api.interceptors.response.use(
  (response: any) => {
    console.log('Response received:', response.data);
    return response.data;
  },
  (error) => {
    console.error('Response error:', error.response?.data || error.message);
    return Promise.reject(error.response?.data || error.message);
  }
);

// Analysis API endpoints
export const analysisAPI = {
  analyzeFile: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const response = await api.post('/analysis/single', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response;
  },
  batchAnalyze: async (files: File[]) => {
    const formData = new FormData();
    files.forEach((file) => {
      formData.append('files', file);
    });
    const response = await api.post('/analysis/batch', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response;
  },
  getAnalysisHistory: async () => {
    const response = await api.get('/analysis/history');
    return response;
  },
  getAnalysisById: async (id: string) => {
    const response = await api.get(`/analysis/${id}`);
    return response;
  },
};

// System API endpoints
export const systemAPI = {
  getStatus: async () => {
    const response = await api.get('/system/status');
    return response;
  },
  getPerformance: async () => {
    const response = await api.get('/system/performance');
    return response;
  },
};

export default api; 