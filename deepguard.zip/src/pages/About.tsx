import React from 'react';

const About: React.FC = () => {
  return (
    <div className="max-w-3xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">About DeepGuard</h1>
      
      <div className="space-y-8">
        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Our Mission</h2>
          <p className="text-gray-600 leading-relaxed">
            DeepGuard is dedicated to combating the spread of manipulated media through advanced
            artificial intelligence technology. Our mission is to provide reliable and accessible
            tools for detecting deepfakes, helping to maintain trust in digital media.
          </p>
        </section>

        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">How It Works</h2>
          <div className="space-y-4">
            <p className="text-gray-600 leading-relaxed">
              Our deepfake detection system uses state-of-the-art machine learning algorithms to
              analyze various aspects of media files, including:
            </p>
            <ul className="list-disc list-inside text-gray-600 space-y-2">
              <li>Facial inconsistencies and artifacts</li>
              <li>Audio-visual synchronization</li>
              <li>Pattern analysis in video frames</li>
              <li>Metadata verification</li>
            </ul>
          </div>
        </section>

        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Technology</h2>
          <p className="text-gray-600 leading-relaxed">
            DeepGuard leverages cutting-edge AI models trained on extensive datasets of both
            authentic and manipulated media. Our system continuously learns and improves to
            stay ahead of evolving deepfake techniques.
          </p>
        </section>

        <section className="bg-white p-8 rounded-lg shadow-md">
          <h2 className="text-2xl font-semibold mb-4">Privacy & Security</h2>
          <p className="text-gray-600 leading-relaxed">
            We take your privacy seriously. All uploaded files are processed securely and
            automatically deleted after analysis. We do not store or share your media files
            with any third parties.
          </p>
        </section>
      </div>
    </div>
  );
};

export default About; 