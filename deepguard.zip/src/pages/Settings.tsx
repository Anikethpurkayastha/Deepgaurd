import React, { useState } from 'react';

interface Settings {
  detectionThreshold: number;
  processingQuality: 'fast' | 'balanced' | 'thorough';
  autoDelete: boolean;
  notifications: boolean;
  darkMode: boolean;
  language: string;
}

const Settings: React.FC = () => {
  const [settings, setSettings] = useState<Settings>({
    detectionThreshold: 85,
    processingQuality: 'balanced',
    autoDelete: true,
    notifications: true,
    darkMode: false,
    language: 'en'
  });

  const handleChange = (key: keyof Settings, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
        <p className="mt-2 text-gray-600">Configure your deepfake detection preferences</p>
      </div>

      <div className="bg-white rounded-xl shadow-soft divide-y divide-gray-200">
        {/* Detection Settings */}
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Detection Settings</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Detection Threshold ({settings.detectionThreshold}%)
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={settings.detectionThreshold}
                onChange={(e) => handleChange('detectionThreshold', parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
              <p className="mt-1 text-sm text-gray-500">
                Higher threshold means more strict detection criteria
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Processing Quality
              </label>
              <select
                value={settings.processingQuality}
                onChange={(e) => handleChange('processingQuality', e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
              >
                <option value="fast">Fast (Lower accuracy)</option>
                <option value="balanced">Balanced</option>
                <option value="thorough">Thorough (Higher accuracy)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Privacy Settings */}
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Privacy Settings</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-medium text-gray-700">
                  Auto-delete after analysis
                </label>
                <p className="text-sm text-gray-500">
                  Automatically delete uploaded files after analysis
                </p>
              </div>
              <button
                onClick={() => handleChange('autoDelete', !settings.autoDelete)}
                className={`${
                  settings.autoDelete ? 'bg-primary-600' : 'bg-gray-200'
                } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2`}
              >
                <span
                  className={`${
                    settings.autoDelete ? 'translate-x-5' : 'translate-x-0'
                  } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                />
              </button>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-medium text-gray-700">
                  Enable notifications
                </label>
                <p className="text-sm text-gray-500">
                  Receive notifications about analysis results
                </p>
              </div>
              <button
                onClick={() => handleChange('notifications', !settings.notifications)}
                className={`${
                  settings.notifications ? 'bg-primary-600' : 'bg-gray-200'
                } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2`}
              >
                <span
                  className={`${
                    settings.notifications ? 'translate-x-5' : 'translate-x-0'
                  } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Appearance Settings */}
        <div className="p-6">
          <h2 className="text-lg font-medium text-gray-900 mb-4">Appearance</h2>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-sm font-medium text-gray-700">
                  Dark Mode
                </label>
                <p className="text-sm text-gray-500">
                  Switch between light and dark theme
                </p>
              </div>
              <button
                onClick={() => handleChange('darkMode', !settings.darkMode)}
                className={`${
                  settings.darkMode ? 'bg-primary-600' : 'bg-gray-200'
                } relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2`}
              >
                <span
                  className={`${
                    settings.darkMode ? 'translate-x-5' : 'translate-x-0'
                  } pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out`}
                />
              </button>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Language
              </label>
              <select
                value={settings.language}
                onChange={(e) => handleChange('language', e.target.value)}
                className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md"
              >
                <option value="en">English</option>
                <option value="es">Español</option>
                <option value="fr">Français</option>
                <option value="de">Deutsch</option>
              </select>
            </div>
          </div>
        </div>
      </div>

      <div className="mt-6 flex justify-end">
        <button
          onClick={() => {/* TODO: Implement save settings */}}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
        >
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default Settings; 