import React from 'react';
import { Link } from 'react-router-dom';

const Home: React.FC = () => {
  return (
    <div className="space-y-16">
      {/* Hero Section */}
      <section className="text-center py-20">
        <h1 className="text-5xl font-bold text-gray-900 mb-6">
          Advanced Deepfake Detection
        </h1>
        <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
          Protect yourself from manipulated media with our state-of-the-art deepfake detection technology.
        </p>
        <Link
          to="/analysis"
          className="inline-block bg-indigo-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-indigo-700 transition-colors"
        >
          Start Analysis
        </Link>
      </section>

      {/* Features Section */}
      <section className="grid md:grid-cols-3 gap-8 py-12">
        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-2xl mb-4">🔍</div>
          <h3 className="text-xl font-semibold mb-2">Advanced Detection</h3>
          <p className="text-gray-600">
            Utilizing cutting-edge AI algorithms to identify manipulated media with high accuracy.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-2xl mb-4">⚡</div>
          <h3 className="text-xl font-semibold mb-2">Real-time Analysis</h3>
          <p className="text-gray-600">
            Get instant results with our fast and efficient processing system.
          </p>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-md">
          <div className="text-indigo-600 text-2xl mb-4">🛡️</div>
          <h3 className="text-xl font-semibold mb-2">Secure Processing</h3>
          <p className="text-gray-600">
            Your files are processed securely with end-to-end encryption.
          </p>
        </div>
      </section>
    </div>
  );
};

export default Home; 