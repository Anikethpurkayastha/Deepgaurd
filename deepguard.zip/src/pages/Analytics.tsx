import React from 'react';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface AnalyticsData {
  dailyScans: {
    date: string;
    total: number;
    deepfakes: number;
  }[];
  detectionAccuracy: {
    name: string;
    value: number;
  }[];
  recentActivity: {
    id: string;
    type: string;
    timestamp: string;
    status: string;
  }[];
}

const mockData: AnalyticsData = {
  dailyScans: [
    { date: '2024-03-01', total: 150, deepfakes: 23 },
    { date: '2024-03-02', total: 180, deepfakes: 31 },
    { date: '2024-03-03', total: 220, deepfakes: 45 },
    { date: '2024-03-04', total: 190, deepfakes: 28 },
    { date: '2024-03-05', total: 250, deepfakes: 42 },
  ],
  detectionAccuracy: [
    { name: 'Video Analysis', value: 95 },
    { name: 'Image Analysis', value: 92 },
    { name: 'Audio Analysis', value: 88 },
  ],
  recentActivity: [
    { id: '1', type: 'Video Scan', timestamp: '2024-03-05 14:30', status: 'Completed' },
    { id: '2', type: 'Batch Analysis', timestamp: '2024-03-05 13:15', status: 'In Progress' },
    { id: '3', type: 'Image Scan', timestamp: '2024-03-05 12:45', status: 'Completed' },
  ],
};

const COLORS = ['#0088FE', '#00C49F', '#FFBB28'];

const Analytics: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Analytics Dashboard</h1>
        <p className="mt-2 text-gray-600">Monitor your deepfake detection performance</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-sm font-medium text-gray-500">Total Scans</h3>
          <p className="text-2xl font-semibold text-gray-900">2,450</p>
          <p className="text-sm text-green-600">+12% from last week</p>
        </div>
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-sm font-medium text-gray-500">Deepfakes Detected</h3>
          <p className="text-2xl font-semibold text-red-600">342</p>
          <p className="text-sm text-red-600">+8% from last week</p>
        </div>
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-sm font-medium text-gray-500">Average Processing Time</h3>
          <p className="text-2xl font-semibold text-gray-900">2.4s</p>
          <p className="text-sm text-green-600">-15% from last week</p>
        </div>
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-sm font-medium text-gray-500">Detection Accuracy</h3>
          <p className="text-2xl font-semibold text-gray-900">94.5%</p>
          <p className="text-sm text-green-600">+2% from last week</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Daily Scans Chart */}
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Daily Scans</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={mockData.dailyScans}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="total"
                  stroke="#8884d8"
                  name="Total Scans"
                />
                <Line
                  type="monotone"
                  dataKey="deepfakes"
                  stroke="#82ca9d"
                  name="Deepfakes"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detection Accuracy Chart */}
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Detection Accuracy by Type</h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={mockData.detectionAccuracy}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {mockData.detectionAccuracy.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-xl shadow-soft overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-medium text-gray-900">Recent Activity</h3>
        </div>
        <div className="divide-y divide-gray-200">
          {mockData.recentActivity.map((activity) => (
            <div key={activity.id} className="px-6 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="flex-shrink-0">
                    <span className="inline-flex items-center justify-center h-8 w-8 rounded-full bg-primary-100">
                      <svg
                        className="h-5 w-5 text-primary-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                        />
                      </svg>
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900">{activity.type}</p>
                    <p className="text-sm text-gray-500">{activity.timestamp}</p>
                  </div>
                </div>
                <span
                  className={`px-3 py-1 rounded-full text-sm font-medium ${
                    activity.status === 'Completed'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-yellow-100 text-yellow-800'
                  }`}
                >
                  {activity.status}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Analytics; 