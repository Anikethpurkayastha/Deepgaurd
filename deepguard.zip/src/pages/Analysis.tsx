import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';

const Analysis: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<{
    isDeepfake: boolean;
    confidence: number;
    details: string;
    analysisPoints: { label: string; value: number }[];
  } | null>(null);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      setFile(acceptedFiles[0]);
      setResult(null);
    }
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi'],
      'image/*': ['.jpg', '.jpeg', '.png']
    },
    maxFiles: 1
  });

  const handleAnalyze = async () => {
    if (!file) return;

    setIsAnalyzing(true);
    // TODO: Implement actual API call to backend
    // Simulating API call with timeout
    setTimeout(() => {
      setResult({
        isDeepfake: Math.random() > 0.5,
        confidence: Math.random() * 100,
        details: "Analysis completed successfully. The system has examined multiple aspects of the media including facial features, audio-visual synchronization, and pattern consistency.",
        analysisPoints: [
          { label: 'Facial Consistency', value: Math.random() * 100 },
          { label: 'Audio-Visual Sync', value: Math.random() * 100 },
          { label: 'Pattern Analysis', value: Math.random() * 100 },
          { label: 'Metadata Verification', value: Math.random() * 100 }
        ]
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Media Analysis</h1>
        <p className="text-lg text-gray-600">
          Upload your media file for deepfake detection analysis
        </p>
      </div>
      
      {/* Upload Section */}
      <div className="bg-white rounded-xl shadow-soft p-8 mb-8">
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragActive
              ? 'border-primary-400 bg-primary-50'
              : 'border-gray-300 hover:border-primary-400'
          }`}
        >
          <input {...getInputProps()} />
          <div className="space-y-4">
            <div className="flex justify-center">
              <svg
                className={`h-12 w-12 ${
                  isDragActive ? 'text-primary-500' : 'text-gray-400'
                }`}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                />
              </svg>
            </div>
            <div className="text-gray-600">
              {file ? (
                <div className="space-y-2">
                  <p className="text-primary-600 font-medium">{file.name}</p>
                  <p className="text-sm text-gray-500">
                    {(file.size / (1024 * 1024)).toFixed(2)} MB
                  </p>
                </div>
              ) : (
                <>
                  <p className="text-lg mb-2">
                    {isDragActive
                      ? 'Drop your file here'
                      : 'Drag and drop your file here'}
                  </p>
                  <p className="text-sm text-gray-500">
                    or click to browse (Supports MP4, MOV, AVI, JPG, PNG)
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
        
        <div className="mt-6 flex justify-center">
          <button
            onClick={handleAnalyze}
            disabled={!file || isAnalyzing}
            className={`inline-flex items-center px-6 py-3 rounded-lg font-semibold transition-colors ${
              !file || isAnalyzing
                ? 'bg-gray-300 cursor-not-allowed'
                : 'bg-primary-600 text-white hover:bg-primary-700 focus:ring-2 focus:ring-offset-2 focus:ring-primary-500'
            }`}
          >
            {isAnalyzing ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Analyzing...
              </>
            ) : (
              'Analyze Media'
            )}
          </button>
        </div>
      </div>

      {/* Results Section */}
      {result && (
        <div className="bg-white rounded-xl shadow-soft p-8">
          <h2 className="text-2xl font-semibold mb-6">Analysis Results</h2>
          
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <span className="text-lg font-medium">Status</span>
              <span
                className={`px-4 py-2 rounded-full text-sm font-medium ${
                  result.isDeepfake
                    ? 'bg-red-100 text-red-800'
                    : 'bg-green-100 text-green-800'
                }`}
              >
                {result.isDeepfake ? 'Deepfake Detected' : 'Authentic Media'}
              </span>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-lg font-medium">Confidence Score</span>
                <span className="text-2xl font-bold text-primary-600">
                  {result.confidence.toFixed(1)}%
                </span>
              </div>

              <div className="space-y-4">
                {result.analysisPoints.map((point, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">{point.label}</span>
                      <span className="text-gray-900">{point.value.toFixed(1)}%</span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary-500 rounded-full transition-all duration-500"
                        style={{ width: `${point.value}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="mt-6 p-4 bg-gray-50 rounded-lg">
              <h3 className="font-medium text-gray-900 mb-2">Analysis Details</h3>
              <p className="text-gray-600">{result.details}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Analysis; 