import React, { useState } from 'react';

interface UserProfile {
  name: string;
  email: string;
  role: string;
  apiKey: string;
  usage: {
    scansThisMonth: number;
    totalScans: number;
    storageUsed: string;
    subscription: string;
  };
}

const mockProfile: UserProfile = {
  name: 'John Doe',
  email: 'john.doe@example.com',
  role: 'Enterprise User',
  apiKey: 'sk_live_123456789abcdef',
  usage: {
    scansThisMonth: 1250,
    totalScans: 5678,
    storageUsed: '2.4 GB',
    subscription: 'Enterprise Plan'
  }
};

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<UserProfile>(mockProfile);
  const [isEditing, setIsEditing] = useState(false);
  const [editedProfile, setEditedProfile] = useState<UserProfile>(mockProfile);

  const handleSave = () => {
    setProfile(editedProfile);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedProfile(profile);
    setIsEditing(false);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Profile Settings</h1>
        <p className="mt-2 text-gray-600">Manage your account and preferences</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Information */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-soft overflow-hidden">
            <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h2 className="text-lg font-medium text-gray-900">Profile Information</h2>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
                >
                  Edit Profile
                </button>
              ) : (
                <div className="space-x-4">
                  <button
                    onClick={handleCancel}
                    className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSave}
                    className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-primary-600 hover:bg-primary-700"
                  >
                    Save Changes
                  </button>
                </div>
              )}
            </div>
            <div className="p-6">
              {isEditing ? (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Name</label>
                    <input
                      type="text"
                      value={editedProfile.name}
                      onChange={(e) => setEditedProfile({ ...editedProfile, name: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Email</label>
                    <input
                      type="email"
                      value={editedProfile.email}
                      onChange={(e) => setEditedProfile({ ...editedProfile, email: e.target.value })}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-primary-500 focus:ring-primary-500"
                    />
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Name</h3>
                    <p className="mt-1 text-sm text-gray-900">{profile.name}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Email</h3>
                    <p className="mt-1 text-sm text-gray-900">{profile.email}</p>
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-gray-500">Role</h3>
                    <p className="mt-1 text-sm text-gray-900">{profile.role}</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Usage Statistics */}
        <div className="space-y-8">
          <div className="bg-white rounded-xl shadow-soft p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">Usage Statistics</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-gray-500">Scans This Month</p>
                <p className="text-2xl font-semibold text-gray-900">{profile.usage.scansThisMonth}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Total Scans</p>
                <p className="text-2xl font-semibold text-gray-900">{profile.usage.totalScans}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Storage Used</p>
                <p className="text-2xl font-semibold text-gray-900">{profile.usage.storageUsed}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Subscription</p>
                <p className="text-2xl font-semibold text-gray-900">{profile.usage.subscription}</p>
              </div>
            </div>
          </div>

          {/* API Key */}
          <div className="bg-white rounded-xl shadow-soft p-6">
            <h3 className="text-lg font-medium text-gray-900 mb-4">API Key</h3>
            <div className="flex items-center space-x-4">
              <code className="flex-1 px-3 py-2 bg-gray-50 rounded text-sm font-mono">
                {profile.apiKey}
              </code>
              <button
                onClick={() => navigator.clipboard.writeText(profile.apiKey)}
                className="inline-flex items-center px-3 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Copy
              </button>
            </div>
            <p className="mt-2 text-sm text-gray-500">
              Keep your API key secure. Do not share it publicly.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile; 