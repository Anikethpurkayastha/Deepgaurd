import React, { useState } from 'react';
import { useDropzone } from 'react-dropzone';

interface BatchFile {
  id: string;
  file: File;
  status: 'pending' | 'processing' | 'completed' | 'error';
  result?: {
    isDeepfake: boolean;
    confidence: number;
  };
}

const BatchAnalysis: React.FC = () => {
  const [files, setFiles] = useState<BatchFile[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);
  const [progress, setProgress] = useState(0);

  const onDrop = (acceptedFiles: File[]) => {
    const newFiles = acceptedFiles.map(file => ({
      id: Math.random().toString(36).substr(2, 9),
      file,
      status: 'pending' as const
    }));
    setFiles(prev => [...prev, ...newFiles]);
  };

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': ['.mp4', '.mov', '.avi'],
      'image/*': ['.jpg', '.jpeg', '.png']
    }
  });

  const handleProcess = async () => {
    setIsProcessing(true);
    setProgress(0);

    // Simulate batch processing
    for (let i = 0; i < files.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      setFiles(prev => prev.map((f, index) => 
        index === i ? {
          ...f,
          status: 'completed',
          result: {
            isDeepfake: Math.random() > 0.5,
            confidence: Math.random() * 100
          }
        } : f
      ));
      setProgress(((i + 1) / files.length) * 100);
    }

    setIsProcessing(false);
  };

  const removeFile = (id: string) => {
    setFiles(prev => prev.filter(f => f.id !== id));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Batch Analysis</h1>
        <p className="mt-2 text-gray-600">Process multiple files simultaneously</p>
      </div>

      {/* Upload Area */}
      <div className="bg-white rounded-xl shadow-soft p-8 mb-8">
        <div
          {...getRootProps()}
          className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
            isDragActive
              ? 'border-primary-400 bg-primary-50'
              : 'border-gray-300 hover:border-primary-400'
          }`}
        >
          <input {...getInputProps()} />
          <div className="space-y-4">
            <div className="flex justify-center">
              <svg
                className={`h-12 w-12 ${
                  isDragActive ? 'text-primary-500' : 'text-gray-400'
                }`}
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                />
              </svg>
            </div>
            <div className="text-gray-600">
              <p className="text-lg mb-2">
                {isDragActive
                  ? 'Drop your files here'
                  : 'Drag and drop files here'}
              </p>
              <p className="text-sm text-gray-500">
                or click to browse (Supports MP4, MOV, AVI, JPG, PNG)
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* File List */}
      {files.length > 0 && (
        <div className="bg-white rounded-xl shadow-soft overflow-hidden mb-8">
          <div className="px-6 py-4 border-b border-gray-200 flex justify-between items-center">
            <h2 className="text-lg font-medium text-gray-900">Files to Process</h2>
            <button
              onClick={handleProcess}
              disabled={isProcessing}
              className={`inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white ${
                isProcessing
                  ? 'bg-gray-400 cursor-not-allowed'
                  : 'bg-primary-600 hover:bg-primary-700'
              }`}
            >
              {isProcessing ? 'Processing...' : 'Start Processing'}
            </button>
          </div>

          {/* Progress Bar */}
          {isProcessing && (
            <div className="px-6 py-4 border-b border-gray-200">
              <div className="w-full bg-gray-200 rounded-full h-2.5">
                <div
                  className="bg-primary-600 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
              <p className="text-sm text-gray-600 mt-2">
                Processing {Math.round(progress)}% complete
              </p>
            </div>
          )}

          <div className="divide-y divide-gray-200">
            {files.map((file) => (
              <div key={file.id} className="px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="flex-shrink-0">
                      <svg className="h-6 w-6 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                      </svg>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-900">{file.file.name}</p>
                      <p className="text-sm text-gray-500">
                        {(file.file.size / (1024 * 1024)).toFixed(2)} MB
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    {file.status === 'completed' && file.result && (
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          file.result.isDeepfake
                            ? 'bg-red-100 text-red-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {file.result.isDeepfake ? 'Deepfake' : 'Authentic'}
                      </span>
                    )}
                    {file.status === 'processing' && (
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-primary-600" />
                    )}
                    <button
                      onClick={() => removeFile(file.id)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Results Summary */}
      {files.some(f => f.status === 'completed') && (
        <div className="bg-white rounded-xl shadow-soft p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Analysis Summary</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-500">Total Files</p>
              <p className="text-2xl font-semibold text-gray-900">{files.length}</p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-500">Deepfakes Detected</p>
              <p className="text-2xl font-semibold text-red-600">
                {files.filter(f => f.result?.isDeepfake).length}
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <p className="text-sm font-medium text-gray-500">Authentic Files</p>
              <p className="text-2xl font-semibold text-green-600">
                {files.filter(f => f.result && !f.result.isDeepfake).length}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BatchAnalysis; 