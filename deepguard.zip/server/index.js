const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// JWT Secret
const JWT_SECRET = 'your-secret-key'; // In production, use environment variable

// Mock database
const users = [];
const analysisHistory = [];

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid token' });
    }
    req.user = user;
    next();
  });
};

// Auth Routes
app.post('/api/auth/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    if (users.find(u => u.email === email)) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const user = {
      id: Date.now().toString(),
      name,
      email,
      password: hashedPassword
    };
    users.push(user);

    // Generate token
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Error creating user' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Find user
    const user = users.find(u => u.email === email);
    if (!user) {
      return res.status(400).json({ error: 'User not found' });
    }

    // Check password
    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(400).json({ error: 'Invalid password' });
    }

    // Generate token
    const token = jwt.sign({ id: user.id, email: user.email }, JWT_SECRET);

    res.json({
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ error: 'Error logging in' });
  }
});

app.post('/api/auth/logout', authenticateToken, (req, res) => {
  res.json({ message: 'Logged out successfully' });
});

app.get('/api/auth/profile', authenticateToken, (req, res) => {
  const user = users.find(u => u.id === req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({
    id: user.id,
    name: user.name,
    email: user.email
  });
});

// System Status Routes
app.get('/api/system/status', (req, res) => {
  res.json({
    status: 'operational',
    version: '1.0.0',
    uptime: process.uptime(),
    timestamp: new Date().toISOString(),
    services: {
      auth: 'operational',
      analysis: 'operational',
      database: 'operational'
    }
  });
});

app.get('/api/system/performance', (req, res) => {
  res.json({
    cpu: {
      usage: Math.random() * 100,
      cores: require('os').cpus().length
    },
    memory: {
      total: require('os').totalmem(),
      free: require('os').freemem()
    },
    uptime: process.uptime()
  });
});

// Analysis Routes
app.post('/api/analysis/single', authenticateToken, (req, res) => {
  // Mock analysis response
  res.json({
    id: Date.now().toString(),
    status: 'completed',
    result: {
      isDeepfake: Math.random() > 0.5,
      confidence: Math.random() * 100,
      timestamp: new Date().toISOString()
    }
  });
});

app.post('/api/analysis/batch', authenticateToken, (req, res) => {
  // Mock batch analysis response
  res.json({
    id: Date.now().toString(),
    status: 'completed',
    results: Array(3).fill(null).map(() => ({
      id: Date.now().toString(),
      isDeepfake: Math.random() > 0.5,
      confidence: Math.random() * 100,
      timestamp: new Date().toISOString()
    }))
  });
});

app.get('/api/analysis/history', authenticateToken, (req, res) => {
  res.json(analysisHistory);
});

// Start server
const PORT = process.env.PORT || 8000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
}); 